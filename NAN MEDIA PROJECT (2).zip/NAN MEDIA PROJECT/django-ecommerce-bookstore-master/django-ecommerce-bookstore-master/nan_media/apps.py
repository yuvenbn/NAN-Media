from django.apps import AppConfig


class NanMediaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nan_media'
