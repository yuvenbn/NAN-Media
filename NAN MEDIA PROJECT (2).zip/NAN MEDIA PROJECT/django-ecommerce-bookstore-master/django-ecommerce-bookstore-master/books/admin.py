from django.contrib import admin
from .models import Book, BookCategory, Order



admin.site.register(Book)
admin.site.register(BookCategory)
admin.site.register(Order)

 