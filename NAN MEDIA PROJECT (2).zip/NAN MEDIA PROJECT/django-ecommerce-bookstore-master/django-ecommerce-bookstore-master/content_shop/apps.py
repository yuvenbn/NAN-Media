from django.apps import AppConfig


class ContentShopConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'content_shop'
