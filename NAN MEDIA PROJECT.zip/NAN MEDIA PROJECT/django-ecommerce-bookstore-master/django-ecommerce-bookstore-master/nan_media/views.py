from django.shortcuts import render

# Create your views here.
from books.models import Book, BookCategory


def create_categories():
        book_categories = [
        'Fiction',
        'Non-Fiction',
        'Children\'s Books',
        'Poetry',
        'Plays and Scripts',
        'Graphic Novels/Comics',
        'Reference Books',
        'Religious/Spiritual',
        'Art and Photography',
        'Science and Technology',
        'Romance'
        ]
        #Creating book categories
        for category in book_categories:
                if not BookCategory.objects.filter(name=category):
                        BookCategory.objects.create(name=category)

def home(request):
    active_links = ["home"]
    title = 'Home'
    books = Book.objects.order_by('-id')[:8] #Querying the 8 most recently added books
    #Create default book categories
    create_categories()
    
    context ={ 
            'active_links': active_links,
            'books': books,
            'title':title,
    }
    return render(request, 'nan_media/home.html', context) 

