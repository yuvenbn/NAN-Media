
from django.urls import path


from django.conf import settings
from django.conf.urls.static import static
from .views import *

urlpatterns = [
    path('', home, name = 'home')
    # path('', BooksListView.as_view(), name = 'list'),
    # path('<int:pk>/', BooksDetailView.as_view(), name = 'detail'),
    # path('<int:pk>/checkout/', BookCheckoutView.as_view(), name = 'checkout'),
    # path('complete/', paymentComplete, name = 'complete'),
    # path('search/', SearchResultsListView.as_view(), name = 'search_results'),

    # #--------
    # path('home/', home, name = 'home'),
]